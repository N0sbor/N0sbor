import "normalize.css";
import { Form } from "./js/form";
import "./js/yt";
new Form();
import axios from "axios";
import { Tools } from "./js/tools";
const $ = new Tools();
const menu = document.querySelector("#menu");
const header = document.querySelector(".main-header");
document.querySelectorAll("a").forEach((link) => {
  if (link.href.includes("#")) {
    link.addEventListener("click", () => {
      menu.click();
    });
  }
});

document.addEventListener("click", (e) => {
  if (menu.checked && !header.contains(e.target)) {
    menu.checked = false;
  }
});
document.addEventListener("scroll", (e) => {
  if (menu.checked && !header.contains(e.target)) {
    menu.checked = false;
  }
});
document.querySelectorAll('a[href^="#"]').forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    const target = document.getElementById(
      link.getAttribute("href").replace("#", "")
    );
    target.scrollIntoView({ behavior: "smooth" });
  });
});
document.querySelectorAll("#form-locaparty").forEach((f) => {
  const formHTML = `
  <input
    type="email"
    placeholder="Digite seu email"
    name="email"
    required
  />
  <span></span>
  <button class="btn btn-primary btn-rounded" type="submit">
    <svg
      width="10"
      height="16"
      viewBox="0 0 10 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      >
      <path
        d="M2 14L8 8L2 2"
        stroke="white"
        stroke-width="4"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      </svg>
    </button>`;
  const newEl = document.createElement("form");
  newEl.classList.add("form");
  newEl.innerHTML = formHTML;
  f.replaceWith(newEl);
});
document.querySelectorAll(".form").forEach((form) => {
  const listener = form.addEventListener("submit", () => {
    form.removeEventListener("submit", listener);
    event.preventDefault();
    const email = form.querySelector("input").value;
    const submitBtn = form.querySelector('button[type="submit"]');
    const span = form.querySelector("span");
    $.removeClass(form, "success");
    $.removeClass(form, "info");
    $.removeClass(form, "error");
    $.addClass(submitBtn, "btn-loading");
    submitBtn.setAttribute('disabled', true);
    axios
      .post(
        "https://gateway.locaparty.com.br/app/v1/usuarios/newsletter",
        { email },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      )
      .then((response) => {
        
        switch (response.status) {
          case 200: {
            $.addClass(form, "success");
            span.innerHTML = "E-mail cadastrado com sucesso!";
            submitBtn.innerHTML = `<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M10 12L13 15L23 5" stroke="#37C377" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M22 13V20C22 20.5304 21.7893 21.0391 21.4142 21.4142C21.0391 21.7893 20.5304 22 20 22H6C5.46957 22 4.96086 21.7893 4.58579 21.4142C4.21071 21.0391 4 20.5304 4 20V6C4 5.46957 4.21071 4.96086 4.58579 4.58579C4.96086 4.21071 5.46957 4 6 4H17" stroke="#37C377" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>`;
            break;
          }
          case 202: {
            $.addClass(form, "info");
            span.innerHTML = "Esse e-mail já está cadastrado!";
            submitBtn.innerHTML = `<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M13 23C18.5228 23 23 18.5228 23 13C23 7.47715 18.5228 3 13 3C7.47715 3 3 7.47715 3 13C3 18.5228 7.47715 23 13 23Z" stroke="#6F8DAE" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M13 9V13" stroke="#6F8DAE" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M13 17H13.01" stroke="#6F8DAE" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>`;
            break;
          }
          default: {
            $.addClass(form, "error");
            span.innerHTML = "Tivemos problemas técnicos";
            submitBtn.innerHTML = `<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 4H6C4.89543 4 4 4.89543 4 6V20C4 21.1046 4.89543 22 6 22H20C21.1046 22 22 21.1046 22 20V6C22 4.89543 21.1046 4 20 4Z" stroke="#F2474E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M10 10L16 16" stroke="#F2474E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 10L10 16" stroke="#F2474E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>`;
          }
        }
        $.removeClass(submitBtn, "btn-primary");
      })
      .catch(() => {
        $.addClass(form, "error");
        span.innerHTML = "Tivemos problemas técnicos";
        submitBtn.innerHTML = `<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M20 4H6C4.89543 4 4 4.89543 4 6V20C4 21.1046 4.89543 22 6 22H20C21.1046 22 22 21.1046 22 20V6C22 4.89543 21.1046 4 20 4Z" stroke="#F2474E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M10 10L16 16" stroke="#F2474E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M16 10L10 16" stroke="#F2474E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>`;
      })
      .finally(() => {
        submitBtn.setAttribute("disabled", true);
        $.removeClass(submitBtn, "btn-loading");
        form.removeEventListener("submit", listener);
      });
  });
});

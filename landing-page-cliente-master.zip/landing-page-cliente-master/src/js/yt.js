
let player;
const playerParent = document.getElementById("player").parentElement;
function onYouTubeIframeAPIReady() {
    console.log('eita');    
  player = new YT.Player("player", {
    height: (playerParent.clientWidth * 9) / 16,
    width: playerParent.clientWidth,
    videoId: "_ihB89tSWvM",
    events: {
      onReady: onPlayerReady,
      onStateChange: onPlayerStateChange,
    },
  });
}

// 4. The API will call this function when the video player is ready.
function onPlayerReady(event) {
  event.target.playVideo();
}

// 5. The API calls this function when the player's state changes.
//    The function indicates that when playing a video (state=1),
//    the player should play for six seconds and then stop.
let done = false;
function onPlayerStateChange(event) {
  if (event.data == YT.PlayerState.PLAYING && !done) {
    setTimeout(stopVideo, 6000);
    done = true;
  }
}
function stopVideo() {
  player.stopVideo();
}
